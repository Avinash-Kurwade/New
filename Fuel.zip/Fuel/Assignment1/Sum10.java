class Sum10{
public static void main(String[]Avinash){
	int sum=0;
	for(int i=1;i<=10;i++)
	sum=sum+i;
	
	System.out.println("Sum of 1 to 10 is " + sum);
}
}