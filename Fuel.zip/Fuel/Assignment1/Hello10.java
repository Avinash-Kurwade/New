class Hello10{
public static void main(String[]Avinash){
	
	for(int i=1;i<=10;i++)
	System.out.println("Welcome to Fuel");
}
}