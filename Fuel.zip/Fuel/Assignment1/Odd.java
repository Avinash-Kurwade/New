import java.util.*;
class Odd{
public static void main(String[]Avinash){
	Scanner scn=new Scanner(System.in);
	  int num = scn.nextInt(); 
	if(num%2==0)
	System.out.println("Please enter Odd number");
	else 
	System.out.println("Odd number " + num );
}
}