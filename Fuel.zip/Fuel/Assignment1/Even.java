import java.util.*;
class Even{
public static void main(String[]Avinash){
	Scanner scn=new Scanner(System.in);
	  int num = scn.nextInt(); 
	if(num%2==0)
	System.out.println("Even number " + num);
	else 
	System.out.println("Please enter Even number " );
}
}