class Sumeven10{
public static void main(String[]Avinash){
	int sum=0;
	for(int i=1;i<=10;i++)	
	//if(i%2==1)
	sum=sum+(2*i);
	
	System.out.println("Sum of first 10 Even is " + sum);
}
}