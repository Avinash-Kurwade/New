class Loop1{
public static void main(String[]Avinash)
{
	int i=0, java =80;
	do{
		System.out.println("Welcome to fuel");
	
		i++;
	}while(i<10);
		i=0;
	do{
		System.out.print(" "+java);
	
		i++;
	}while(i<15);
	
}
}