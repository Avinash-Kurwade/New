class Loops{
	public static void main (String[] avinash)
	{
		 int z=50;
		 /*do{
		 
		System.out.println(z);
		z++;
		 }while (z<10);*/
		 if(z>=55)
			 System.out.println("Welcome to FUEL");
		 else 
			 System.out.println("You are not eligible");
		 
		 
		 
	}
}