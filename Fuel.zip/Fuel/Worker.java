/*
salary 5000
>10000 manager
7000-10000 Devloper
5000-7000 tester
<5000 office boy

*/
import java.util.*;
class Worker{
	public static void main(String[] Avinash){
	Scanner scn=new Scanner(System.in);
	  int salary = scn.nextInt(); 
	  System.out.println(salary);
	  if(salary>10000)
		  System.out.println("The person is Manager");
	  else if(salary>=7000)
		  System.out.println("The person is Devloper");
	  else if(salary>=5000)
		  System.out.println("The person is Tester");
	  else
		  System.out.println("The person is Office boy");
	}
}