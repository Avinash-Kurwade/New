class Voting{
	public static void main(String[]Avinash)
	{
			int a=27;
		
		if(a>=18)
			System.out.println("You are eligible You can vote");
		else
			System.out.println("You are not eligible You Can not vote");
	}	
}