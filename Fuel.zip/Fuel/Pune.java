
class Pune
{
	public static void main(String[] args ){

		System.out.println("WELCOME TO PUNE");
		int x=50;
		System.out.println(x);
		double d = 80.99;
		System.out.println(d);
	
}
}