import java.util.*;
class Fuelp{
public static void main(String[] Avinash)
{
	  Scanner scn=new Scanner(System.in);
	  int m = scn.nextInt(); 
	  System.out.println(m);
	  if(m>=60)
		  System.out.println("You are Eligible for java and AI/ML");
	  else if(m>=50)
		  System.out.println("You are eligible for java only");
	  else
		  System.out.println("You are not eligible for current batch");
	  
}
}