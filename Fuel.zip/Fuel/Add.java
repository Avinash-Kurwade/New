class Add {
public static void main(String [] avi)
{
	int a=10;
	int b=15;
	System.out.println(a+b);
}	
}
