class Forloop{
public static void main(String [] Avinash){
	for(int i=51; i<=100; i++)
	System.out.println(i);
}
}